public class Main {
    public static void main(String[] args) {
        coche micoche = new coche();
        micoche.sumarpuertas();
        micoche.sumarpuertas();
        System.out.println(micoche.puertas);

    }
}

    class coche {
        public int puertas = 2;

        public void sumarpuertas() {
            this.puertas++;
        }
    }
